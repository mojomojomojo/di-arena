Robocode
===================
*Build the best - destroy the rest!*

Robocode is a programming game, where the goal is to develop a robot battle tank to battle against other tanks in Java or .NET. The robot battles are running in real-time and on-screen.
  
Read [Introduction] (http://robocode.sourceforge.net/docs/ReadMe.html)  
Continue reading on [Robocode home page] (http://robocode.sourceforge.net/)  
Learn from community at [RoboWiki] (http://robowiki.net/)  
Talk to developers at [robocode-developers] (http://groups.google.com/group/robocode-developers)  

Enjoy!
