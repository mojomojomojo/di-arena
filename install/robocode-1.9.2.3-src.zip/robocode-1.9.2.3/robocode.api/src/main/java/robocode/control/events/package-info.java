/**
 * Battle events that occurs during a game, and which are used for the
 * robocode.control.IBattleListener class.
 */
package robocode.control.events;
